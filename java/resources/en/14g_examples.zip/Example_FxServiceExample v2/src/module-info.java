module FxServiceExample {

    requires javafx.fxml;
    requires javafx.controls;

    opens sample;

}