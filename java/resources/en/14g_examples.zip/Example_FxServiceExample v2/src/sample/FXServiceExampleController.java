package sample;

import javafx.application.Platform;
import javafx.concurrent.ScheduledService;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.util.Duration;

import java.util.Random;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class FXServiceExampleController
{
    @FXML
    private Button button;

    @FXML
    private Label threadsPending;

    @FXML
    private Label threadsFinished;

    private ScheduledService<Boolean> schedServ;
    private ThreadPoolExecutor executor;

    public void initialize()
    {
        schedServ = new ScheduledService<Boolean>()
        {
            @Override
            protected Task<Boolean> createTask()
            {
                return new Task<Boolean>()
                {
                    @Override
                    protected Boolean call() throws Exception
                    {
                        Platform.runLater(() -> {
                            threadsPending.setText("Pending threads: " +
                                    (executor.getTaskCount() -
                                            executor.getCompletedTaskCount()));

                            threadsFinished.setText("Finished threads: " +
                                    executor.getCompletedTaskCount());
                        });
                        return executor.isTerminated();
                    }
                };
            }
        };

        schedServ.setDelay(Duration.millis(500)); // Will start after 0.5s
        schedServ.setPeriod(Duration.seconds(1)); // Runs every second after
        schedServ.setOnSucceeded(e -> {
            if(schedServ.getValue())
            {
                // Executor finished
                schedServ.cancel(); // Cancel service (stop it).
                button.setDisable(false);
            }
        });
    }

    @FXML
    private void startThreads(ActionEvent event)
    {
        button.setDisable(true);
        executor = (ThreadPoolExecutor) Executors.newFixedThreadPool(
                Runtime.getRuntime().availableProcessors());

        for(int i = 0; i < 20; i++)
        {
            executor.execute(() -> {
                Random rnd = new Random();
                try
                {
                    TimeUnit.MILLISECONDS.sleep(500 + rnd.nextInt(5000));
                } catch (InterruptedException ex) { }
            });
        }
        executor.shutdown();
        schedServ.restart();// Start the scheduled service (or restart it)
    }
}
