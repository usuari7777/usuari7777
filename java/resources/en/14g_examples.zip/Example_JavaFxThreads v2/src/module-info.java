module Example.JavaFxThreads {

    requires javafx.fxml;
    requires javafx.controls;
    opens examplejavafx;
}