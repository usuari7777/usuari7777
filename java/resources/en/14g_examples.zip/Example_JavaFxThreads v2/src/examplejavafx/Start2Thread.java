package examplejavafx;

import javafx.application.Platform;
import javafx.scene.control.Label;

class Start2Thread extends Thread
{
    // Progress label to update its text
    Label lblProgress;

    public Start2Thread(Label lblProgress)
    {
        this.lblProgress = lblProgress;
    }

    @Override
    public void run()
    {
        for (int progress = 1; progress <= 10; progress++)
        {
            try
            {
                Thread.sleep(1000);
                //lblProgress.setText("" + (progress*10) + "% completed");
                int finalProgress = progress;
                Platform.runLater(() -> lblProgress.setText("" + (finalProgress *10) + "% completed"));
            } catch (Exception ex) {}
        }
    }
}
