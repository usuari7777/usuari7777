package examplejavafx;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Example_JavaFXThreads extends Application 
{
    
    @Override
    public void start(Stage primaryStage) 
    {
        Label lblProgress = new Label("");
        Button btnStart1 = new Button("Start copy (1)");
        Button btnStart2 = new Button("Start copy (2)");

        btnStart1.setOnAction(e -> {
           for(int progress = 1; progress <= 10; progress++)
           {
               try
               {
                   Thread.sleep(1000);
                   lblProgress.setText("" + (progress*10) + "% completed");
               } catch (Exception ex) {}
           }
        });


        btnStart2.setOnAction(e ->
        {
            Thread t = new Start2Thread(lblProgress);
            t.start();
        });

        VBox vb = new VBox(20);
        vb.setAlignment(Pos.CENTER);
        vb.getChildren().addAll(lblProgress, btnStart1, btnStart2);
        
        Scene scene = new Scene(vb, 300, 400);        
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) 
    {
        launch(args);
    }
    
}
