package sample;

import javafx.concurrent.Service;
import javafx.concurrent.Task;

class FileService extends Service<String>
{
    @Override
    protected Task<String> createTask()
    {
        return new Task<String>()
        {
            @Override
            protected String call() throws Exception
            {
                for (int progress = 1; progress <= 10; progress++)
                {
                    try
                    {
                        Thread.sleep(1000);
                        updateMessage("" + (progress * 10) + "% completed");
                    } catch (Exception ex) { }
                }
                return "Copy completed";
            }
        };
    }
}
