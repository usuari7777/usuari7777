package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class FXServiceExampleController
{
    @FXML
    private Button btnStart;
    @FXML
    private Label lblProgress;
    @FXML
    private Button btnCancel;

    FileService service;

    @FXML
    private void start(ActionEvent event)
    {
        setProperties(true, false);
        service.start();
    }

    @FXML
    private void cancel(ActionEvent event)
    {
        setProperties(false, true);
        service.cancel();
    }


    public void initialize()
    {
        service = new FileService();

        // Events to be fired when service finishes/cancels/fails...

        service.setOnSucceeded(e -> {
            setProperties(false, true);
            System.out.println(service.getValue());
            service.reset();
        });

        service.setOnCancelled(e -> {
            setProperties(false, true);
            service.reset();
        });

        service.setOnFailed(e -> {
            setProperties(false, true);
            service.reset();
        });

        // Bind label text property to service
        lblProgress.textProperty().bind(service.messageProperty());
        btnCancel.setDisable(true);
    }

    // Method to disable/enable buttons and set label's text from events
    private void setProperties(boolean disableStart, boolean disableCancel)
    {
        btnStart.setDisable(disableStart);
        btnCancel.setDisable(disableCancel);
    }
}
